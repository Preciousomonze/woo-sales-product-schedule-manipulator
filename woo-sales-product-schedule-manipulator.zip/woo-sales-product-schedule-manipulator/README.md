# Woo Sales Product Schedule Manipulator
This helps you modify the status of a product after the countdown or sales period has ended. Requires **WooCommerce**.

### Note
Only Confirmed to work with Simple and Variable Products for now. 🗿

Current Available status
- Trash
- Draft


Dependent on **WooCommerce**.

### How to Install
Same way you install All other WordPress plugins, DKM abeg 🥴

##### Have a nice day. 🥞
